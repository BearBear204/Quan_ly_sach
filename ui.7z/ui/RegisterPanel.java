package ui;

import library.ClientService;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class RegisterPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JTextField txtUsername;
    private JPasswordField txtPassword, txtConfirm;

    public interface RegisterHandler { void register(String u, String p, String c); }

    // Constructor chính: build UI
    public RegisterPanel(RegisterHandler onRegister, Runnable onBack) {
        setLayout(new GridBagLayout());
        setBackground(new Color(230, 245, 255)); // nền xanh nhạt

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(30, 40, 30, 40)
        ));

        GroupLayout layout = new GroupLayout(card);
        card.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        JLabel title = new JLabel("Đăng ký tài khoản mới", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(0, 123, 255));

        JLabel lblUser = new JLabel("Tên đăng nhập:");
        txtUsername = new JTextField();
        txtUsername.setPreferredSize(new Dimension(220, 30));

        JLabel lblPass = new JLabel("Mật khẩu:");
        txtPassword = new JPasswordField();
        txtPassword.setPreferredSize(new Dimension(220, 30));

        JLabel lblConfirm = new JLabel("Xác nhận mật khẩu:");
        txtConfirm = new JPasswordField();
        txtConfirm.setPreferredSize(new Dimension(220, 30));

        JButton btnReg = new JButton("Đăng ký");
        stylePrimaryButton(btnReg);
        btnReg.addActionListener(e -> onRegister.register(
                txtUsername.getText().trim(),
                new String(txtPassword.getPassword()).trim(),
                new String(txtConfirm.getPassword()).trim()
        ));

        JButton btnBack = new JButton("Quay lại");
        styleAccentButton(btnBack);
        btnBack.addActionListener(e -> onBack.run());

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        btnPanel.setOpaque(false);
        btnPanel.add(btnReg);
        btnPanel.add(btnBack);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(title)
                .addGroup(layout.createSequentialGroup()
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                        .addComponent(lblUser)
                        .addComponent(lblPass)
                        .addComponent(lblConfirm))
                    .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addComponent(txtUsername)
                        .addComponent(txtPassword)
                        .addComponent(txtConfirm)))
                .addComponent(btnPanel)
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(title)
                .addGap(20)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblUser)
                    .addComponent(txtUsername))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPass)
                    .addComponent(txtPassword))
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(lblConfirm)
                    .addComponent(txtConfirm))
                .addGap(20)
                .addComponent(btnPanel)
        );

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0;
        add(card, gbc);
    }

    // Constructor tiện lợi cho ClientService
    public RegisterPanel(ClientService service, Runnable onBack) {
        this((username, password, confirm) -> {
            if (username.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Vui lòng nhập đầy đủ thông tin!");
                return;
            }
            if (!password.equals(confirm)) {
                JOptionPane.showMessageDialog(null, "Mật khẩu và xác nhận mật khẩu không khớp!");
                return;
            }
            service.sendCommand("REGISTER " + username + "|" + password);
        }, onBack);
    }

    // Style helper cho nút chính
    private void stylePrimaryButton(JButton btn) {
        btn.setBackground(new Color(0, 123, 255));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(0, 150, 220)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(0, 123, 255)); }
        });
    }

    // Style helper cho nút phụ
    private void styleAccentButton(JButton btn) {
        btn.setBackground(new Color(0, 180, 140));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(0, 200, 160)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(0, 180, 140)); }
        });
    }
}
